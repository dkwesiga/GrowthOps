import {
  boolean,
  int,
  json,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  varchar,
  float,
} from "drizzle-orm/mysql-core";

// ─── Users ────────────────────────────────────────────────────────────────────
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin", "owner", "editor", "viewer"]).default("user").notNull(),
  organizationId: int("organizationId"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// ─── Organizations ────────────────────────────────────────────────────────────
export const organizations = mysqlTable("organizations", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  planType: varchar("planType", { length: 64 }).default("free").notNull(),
  billingStatus: varchar("billingStatus", { length: 64 }).default("active").notNull(),
  stripeCustomerId: varchar("stripeCustomerId", { length: 255 }),
  stripeSubscriptionId: varchar("stripeSubscriptionId", { length: 255 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Organization = typeof organizations.$inferSelect;

// ─── Workspaces ───────────────────────────────────────────────────────────────
export const workspaces = mysqlTable("workspaces", {
  id: int("id").autoincrement().primaryKey(),
  organizationId: int("organizationId").notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  type: mysqlEnum("type", ["local_service_business", "b2b_saas", "other"]).default("other").notNull(),
  status: mysqlEnum("status", ["active", "inactive", "archived"]).default("active").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Workspace = typeof workspaces.$inferSelect;

// ─── Brand Profiles ───────────────────────────────────────────────────────────
export const brandProfiles = mysqlTable("brand_profiles", {
  id: int("id").autoincrement().primaryKey(),
  workspaceId: int("workspaceId").notNull().unique(),
  brandName: varchar("brandName", { length: 255 }).notNull(),
  website: varchar("website", { length: 500 }),
  businessType: varchar("businessType", { length: 255 }),
  audience: text("audience"),
  painPoints: text("painPoints"),
  servicesOrProducts: text("servicesOrProducts"),
  offers: text("offers"),
  ctas: text("ctas"),
  toneOfVoice: text("toneOfVoice"),
  prohibitedClaims: text("prohibitedClaims"),
  complianceNotes: text("complianceNotes"),
  geographicFocus: varchar("geographicFocus", { length: 255 }),
  seedKeywords: text("seedKeywords"),
  competitors: text("competitors"),
  contactInfo: text("contactInfo"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type BrandProfile = typeof brandProfiles.$inferSelect;

// ─── Campaigns ────────────────────────────────────────────────────────────────
export const campaigns = mysqlTable("campaigns", {
  id: int("id").autoincrement().primaryKey(),
  workspaceId: int("workspaceId").notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  objective: text("objective"),
  audience: text("audience"),
  offer: text("offer"),
  channel: varchar("channel", { length: 255 }),
  status: mysqlEnum("status", ["draft", "active", "paused", "completed", "archived"]).default("draft").notNull(),
  startDate: timestamp("startDate"),
  endDate: timestamp("endDate"),
  kpis: text("kpis"),
  notes: text("notes"),
  aiPlan: text("aiPlan"),
  contentChecklist: text("contentChecklist"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Campaign = typeof campaigns.$inferSelect;

// ─── Leads ────────────────────────────────────────────────────────────────────
export const leads = mysqlTable("leads", {
  id: int("id").autoincrement().primaryKey(),
  workspaceId: int("workspaceId").notNull(),
  campaignId: int("campaignId"),
  companyName: varchar("companyName", { length: 255 }),
  contactName: varchar("contactName", { length: 255 }),
  roleTitle: varchar("roleTitle", { length: 255 }),
  email: varchar("email", { length: 320 }),
  phone: varchar("phone", { length: 50 }),
  website: varchar("website", { length: 500 }),
  linkedinUrl: varchar("linkedinUrl", { length: 500 }),
  location: varchar("location", { length: 255 }),
  industry: varchar("industry", { length: 255 }),
  fleetSizeEstimate: varchar("fleetSizeEstimate", { length: 100 }),
  painPoint: text("painPoint"),
  source: varchar("source", { length: 255 }),
  fitScore: float("fitScore"),
  urgencyScore: float("urgencyScore"),
  status: mysqlEnum("status", [
    "new", "researched", "scored", "draft_ready", "approved_for_contact",
    "contacted_manually", "replied", "booked", "not_fit", "follow_up_later",
    "closed_won", "closed_lost"
  ]).default("new").notNull(),
  lastTouchpointAt: timestamp("lastTouchpointAt"),
  nextFollowUpAt: timestamp("nextFollowUpAt"),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Lead = typeof leads.$inferSelect;

// ─── Content Drafts ───────────────────────────────────────────────────────────
export const contentDrafts = mysqlTable("content_drafts", {
  id: int("id").autoincrement().primaryKey(),
  workspaceId: int("workspaceId").notNull(),
  campaignId: int("campaignId"),
  leadId: int("leadId"),
  contentType: mysqlEnum("contentType", [
    "linkedin_post", "facebook_post", "x_post", "email",
    "blog_outline", "blog_article", "seo_page", "geo_answer_page",
    "review_request", "referral_request", "ad_copy", "landing_page_copy",
    "thought_leadership_post"
  ]).notNull(),
  channel: varchar("channel", { length: 100 }),
  title: varchar("title", { length: 500 }).notNull(),
  body: text("body").notNull(),
  critiqueNotes: text("critiqueNotes"),
  aiRationale: text("aiRationale"),
  riskNotes: text("riskNotes"),
  cta: varchar("cta", { length: 500 }),
  status: mysqlEnum("status", [
    "draft", "needs_review", "revision_requested", "approved", "rejected",
    "gmail_draft_created", "sent_manually", "published_manually", "archived"
  ]).default("draft").notNull(),
  version: int("version").default(1).notNull(),
  createdByAgent: boolean("createdByAgent").default(false).notNull(),
  approvedBy: int("approvedBy"),
  approvedAt: timestamp("approvedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type ContentDraft = typeof contentDrafts.$inferSelect;

// ─── Approvals ────────────────────────────────────────────────────────────────
export const approvals = mysqlTable("approvals", {
  id: int("id").autoincrement().primaryKey(),
  workspaceId: int("workspaceId").notNull(),
  contentDraftId: int("contentDraftId").notNull(),
  requestedBy: int("requestedBy"),
  reviewedBy: int("reviewedBy"),
  status: mysqlEnum("status", [
    "draft", "needs_review", "revision_requested", "approved", "rejected",
    "gmail_draft_created", "sent_manually", "published_manually", "archived"
  ]).default("needs_review").notNull(),
  feedback: text("feedback"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  reviewedAt: timestamp("reviewedAt"),
});

export type Approval = typeof approvals.$inferSelect;

// ─── Agent Runs ───────────────────────────────────────────────────────────────
export const agentRuns = mysqlTable("agent_runs", {
  id: int("id").autoincrement().primaryKey(),
  workspaceId: int("workspaceId").notNull(),
  agentName: varchar("agentName", { length: 255 }).notNull(),
  loopName: varchar("loopName", { length: 255 }),
  triggerType: varchar("triggerType", { length: 100 }),
  inputJson: text("inputJson"),
  outputJson: text("outputJson"),
  modelUsed: varchar("modelUsed", { length: 255 }),
  status: mysqlEnum("status", ["running", "completed", "failed", "cancelled"]).default("running").notNull(),
  errorMessage: text("errorMessage"),
  createdRecordsJson: text("createdRecordsJson"),
  tokenUsageJson: text("tokenUsageJson"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  completedAt: timestamp("completedAt"),
});

export type AgentRun = typeof agentRuns.$inferSelect;

// ─── Performance Logs ─────────────────────────────────────────────────────────
export const performanceLogs = mysqlTable("performance_logs", {
  id: int("id").autoincrement().primaryKey(),
  workspaceId: int("workspaceId").notNull(),
  campaignId: int("campaignId"),
  contentDraftId: int("contentDraftId"),
  channel: varchar("channel", { length: 100 }),
  metricName: varchar("metricName", { length: 255 }).notNull(),
  metricValue: float("metricValue").notNull(),
  source: varchar("source", { length: 255 }),
  recordedAt: timestamp("recordedAt").defaultNow().notNull(),
});

// ─── Integrations ─────────────────────────────────────────────────────────────
export const integrations = mysqlTable("integrations", {
  id: int("id").autoincrement().primaryKey(),
  organizationId: int("organizationId").notNull(),
  workspaceId: int("workspaceId"),
  provider: mysqlEnum("provider", ["openrouter", "gmail", "google_sheets", "website_ingestion", "activepieces"]).notNull(),
  status: mysqlEnum("status", ["connected", "disconnected", "error", "mock"]).default("mock").notNull(),
  configJson: text("configJson"),
  lastSyncAt: timestamp("lastSyncAt"),
  errorMessage: text("errorMessage"),
  mockMode: boolean("mockMode").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Integration = typeof integrations.$inferSelect;

// ─── Usage Records ────────────────────────────────────────────────────────────
export const usageRecords = mysqlTable("usage_records", {
  id: int("id").autoincrement().primaryKey(),
  organizationId: int("organizationId").notNull(),
  workspaceId: int("workspaceId").notNull(),
  usageType: varchar("usageType", { length: 100 }).notNull(),
  quantity: int("quantity").default(1).notNull(),
  metadataJson: text("metadataJson"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});
