CREATE TABLE `agent_runs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`workspaceId` int NOT NULL,
	`agentName` varchar(255) NOT NULL,
	`loopName` varchar(255),
	`triggerType` varchar(100),
	`inputJson` text,
	`outputJson` text,
	`modelUsed` varchar(255),
	`status` enum('running','completed','failed','cancelled') NOT NULL DEFAULT 'running',
	`errorMessage` text,
	`createdRecordsJson` text,
	`tokenUsageJson` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`completedAt` timestamp,
	CONSTRAINT `agent_runs_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `approvals` (
	`id` int AUTO_INCREMENT NOT NULL,
	`workspaceId` int NOT NULL,
	`contentDraftId` int NOT NULL,
	`requestedBy` int,
	`reviewedBy` int,
	`status` enum('draft','needs_review','revision_requested','approved','rejected','gmail_draft_created','sent_manually','published_manually','archived') NOT NULL DEFAULT 'needs_review',
	`feedback` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`reviewedAt` timestamp,
	CONSTRAINT `approvals_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `brand_profiles` (
	`id` int AUTO_INCREMENT NOT NULL,
	`workspaceId` int NOT NULL,
	`brandName` varchar(255) NOT NULL,
	`website` varchar(500),
	`businessType` varchar(255),
	`audience` text,
	`painPoints` text,
	`servicesOrProducts` text,
	`offers` text,
	`ctas` text,
	`toneOfVoice` text,
	`prohibitedClaims` text,
	`complianceNotes` text,
	`geographicFocus` varchar(255),
	`seedKeywords` text,
	`competitors` text,
	`contactInfo` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `brand_profiles_id` PRIMARY KEY(`id`),
	CONSTRAINT `brand_profiles_workspaceId_unique` UNIQUE(`workspaceId`)
);
--> statement-breakpoint
CREATE TABLE `campaigns` (
	`id` int AUTO_INCREMENT NOT NULL,
	`workspaceId` int NOT NULL,
	`name` varchar(255) NOT NULL,
	`objective` text,
	`audience` text,
	`offer` text,
	`channel` varchar(255),
	`status` enum('draft','active','paused','completed','archived') NOT NULL DEFAULT 'draft',
	`startDate` timestamp,
	`endDate` timestamp,
	`kpis` text,
	`notes` text,
	`aiPlan` text,
	`contentChecklist` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `campaigns_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `content_drafts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`workspaceId` int NOT NULL,
	`campaignId` int,
	`leadId` int,
	`contentType` enum('linkedin_post','facebook_post','x_post','email','blog_outline','blog_article','seo_page','geo_answer_page','review_request','referral_request','ad_copy','landing_page_copy','thought_leadership_post') NOT NULL,
	`channel` varchar(100),
	`title` varchar(500) NOT NULL,
	`body` text NOT NULL,
	`critiqueNotes` text,
	`aiRationale` text,
	`riskNotes` text,
	`cta` varchar(500),
	`status` enum('draft','needs_review','revision_requested','approved','rejected','gmail_draft_created','sent_manually','published_manually','archived') NOT NULL DEFAULT 'draft',
	`version` int NOT NULL DEFAULT 1,
	`createdByAgent` boolean NOT NULL DEFAULT false,
	`approvedBy` int,
	`approvedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `content_drafts_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `integrations` (
	`id` int AUTO_INCREMENT NOT NULL,
	`organizationId` int NOT NULL,
	`workspaceId` int,
	`provider` enum('openrouter','gmail','google_sheets','website_ingestion','activepieces') NOT NULL,
	`status` enum('connected','disconnected','error','mock') NOT NULL DEFAULT 'mock',
	`configJson` text,
	`lastSyncAt` timestamp,
	`errorMessage` text,
	`mockMode` boolean NOT NULL DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `integrations_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `leads` (
	`id` int AUTO_INCREMENT NOT NULL,
	`workspaceId` int NOT NULL,
	`campaignId` int,
	`companyName` varchar(255),
	`contactName` varchar(255),
	`roleTitle` varchar(255),
	`email` varchar(320),
	`phone` varchar(50),
	`website` varchar(500),
	`linkedinUrl` varchar(500),
	`location` varchar(255),
	`industry` varchar(255),
	`fleetSizeEstimate` varchar(100),
	`painPoint` text,
	`source` varchar(255),
	`fitScore` float,
	`urgencyScore` float,
	`status` enum('new','researched','scored','draft_ready','approved_for_contact','contacted_manually','replied','booked','not_fit','follow_up_later','closed_won','closed_lost') NOT NULL DEFAULT 'new',
	`lastTouchpointAt` timestamp,
	`nextFollowUpAt` timestamp,
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `leads_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `organizations` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(255) NOT NULL,
	`planType` varchar(64) NOT NULL DEFAULT 'free',
	`billingStatus` varchar(64) NOT NULL DEFAULT 'active',
	`stripeCustomerId` varchar(255),
	`stripeSubscriptionId` varchar(255),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `organizations_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `performance_logs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`workspaceId` int NOT NULL,
	`campaignId` int,
	`contentDraftId` int,
	`channel` varchar(100),
	`metricName` varchar(255) NOT NULL,
	`metricValue` float NOT NULL,
	`source` varchar(255),
	`recordedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `performance_logs_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `usage_records` (
	`id` int AUTO_INCREMENT NOT NULL,
	`organizationId` int NOT NULL,
	`workspaceId` int NOT NULL,
	`usageType` varchar(100) NOT NULL,
	`quantity` int NOT NULL DEFAULT 1,
	`metadataJson` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `usage_records_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `workspaces` (
	`id` int AUTO_INCREMENT NOT NULL,
	`organizationId` int NOT NULL,
	`name` varchar(255) NOT NULL,
	`type` enum('local_service_business','b2b_saas','other') NOT NULL DEFAULT 'other',
	`status` enum('active','inactive','archived') NOT NULL DEFAULT 'active',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `workspaces_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `users` MODIFY COLUMN `role` enum('user','admin','owner','editor','viewer') NOT NULL DEFAULT 'user';--> statement-breakpoint
ALTER TABLE `users` ADD `organizationId` int;